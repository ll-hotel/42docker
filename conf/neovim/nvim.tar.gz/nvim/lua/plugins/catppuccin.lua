-------- lua/plugins/catppuccin.lua --------
return { 'catppuccin/nvim' }
