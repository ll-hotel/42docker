-------- init.lua --------
require('config.lazy')
require('config.options')
